package com.ayberk.rickandmorty20.models

data class İnfo(
    val count: Int,
    val next: String,
    val pages: Int,
    val prev: Any
)