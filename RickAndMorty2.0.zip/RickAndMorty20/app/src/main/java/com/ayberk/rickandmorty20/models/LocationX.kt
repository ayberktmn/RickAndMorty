package com.ayberk.rickandmorty20.models

data class LocationX(
    val info: İnfoX,
    val results: List<ResultX>
)