package com.ayberk.rickandmorty20.util

object Constants {

    val THEME_KEY = "isDarkMode"
    val FIRST_RUN_KEY = "isFirstRun"
    val PREF_NAME = "RickandMortyPref"
}