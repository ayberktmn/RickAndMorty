package com.ayberk.rickandmorty20.models

data class Origin(
    val name: String,
    val url: String
)