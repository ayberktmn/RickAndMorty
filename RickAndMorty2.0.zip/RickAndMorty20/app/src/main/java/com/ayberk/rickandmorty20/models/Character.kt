package com.ayberk.rickandmorty20.models

data class Character(
    val info: İnfo,
    val results: List<Result>
)