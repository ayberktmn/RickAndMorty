package com.ayberk.rickandmorty20.models

data class Location(
    val name: String,
    val url: String
)